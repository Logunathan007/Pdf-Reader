import PyPDF2
import os
merger = PyPDF2.PdfFileMerger()
for i in range(1,5):
    merger.append("%d.pdf"%i)
merger.write("Physics_11th_12th.pdf")
merger.close()
